import requests

def get_user(user_id):
    r = requests.get(f"https://api.example.com/users/{user_id}")
    return r.json()

'''
Issues with this code ?


'''
