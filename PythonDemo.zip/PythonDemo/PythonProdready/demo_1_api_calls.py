"""
Demo 1: Production-Grade API Calls
===================================

This demonstrates the difference between basic API calls and production-ready code.

Run this file to see:
1. Bad practice (will fail gracefully in demo)
2. Good practice with retries, timeouts, and logging
"""

import logging
import time
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# ============================================================================
# BAD PRACTICE - Don't do this in production!
# ============================================================================

def get_user_bad(user_id):
    """
    Problems:
    - No timeout (can hang forever)
    - No error handling (crashes on network issues)
    - No retries (temporary failures become permanent)
    - No logging (can't debug issues)
    - No type hints (unclear what it returns)
    """
    r = requests.get(f"https://jsonplaceholder.typicode.com/users/{user_id}")
    return r.json()


# ============================================================================
# GOOD PRACTICE - Production-ready code
# ============================================================================

# Create a session with automatic retries
session = requests.Session()
retries = Retry(
    total=3,  # Retry up to 3 times
    backoff_factor=0.5,  # Wait 0.5s, 1s, 2s between retries
    status_forcelist=[500, 502, 503, 504],  # Retry on server errors
    allowed_methods=["GET", "POST", "PUT", "DELETE"]  # Which methods to retry
)
adapter = HTTPAdapter(max_retries=retries)
session.mount("https://", adapter)
session.mount("http://", adapter)


def get_user_good(user_id: int, timeout: int = 3) -> dict:
    """
    Fetch user data with proper error handling.
    
    Args:
        user_id: The user ID to fetch
        timeout: Request timeout in seconds
        
    Returns:
        dict: User data
        
    Raises:
        requests.exceptions.Timeout: If request times out
        requests.exceptions.HTTPError: If HTTP error occurs
        requests.exceptions.RequestException: For other request errors
    """
    base_url = "https://jsonplaceholder.typicode.com"
    
    try:
        logger.info(f"Fetching user {user_id}")
        
        response = session.get(
            f"{base_url}/users/{user_id}",
            timeout=timeout
        )
        
        # Raise exception for 4xx/5xx status codes
        response.raise_for_status()
        
        logger.info(f"Successfully fetched user {user_id}")
        return response.json()
        
    except requests.exceptions.Timeout:
        logger.error(f"Timeout fetching user {user_id}")
        raise
        
    except requests.exceptions.HTTPError as e:
        logger.error(f"HTTP error for user {user_id}: {e.response.status_code}")
        raise
        
    except requests.exceptions.RequestException as e:
        logger.exception(f"Unexpected error fetching user {user_id}")
        raise


def get_multiple_users(user_ids: list[int]) -> list[dict]:
    """
    Fetch multiple users with error handling for individual failures.
    
    This demonstrates how to handle partial failures - if one user fetch fails,
    we continue with the others.
    """
    users = []
    failed_ids = []
    
    for user_id in user_ids:
        try:
            user = get_user_good(user_id)
            users.append(user)
        except Exception as e:
            logger.warning(f"Failed to fetch user {user_id}: {e}")
            failed_ids.append(user_id)
    
    if failed_ids:
        logger.warning(f"Failed to fetch {len(failed_ids)} users: {failed_ids}")
    
    logger.info(f"Successfully fetched {len(users)}/{len(user_ids)} users")
    return users


# ============================================================================
# ADVANCED: Circuit Breaker Pattern
# ============================================================================

class SimpleCircuitBreaker:
    """
    Prevents calling a failing service repeatedly.
    
    States:
    - CLOSED: Normal operation, requests go through
    - OPEN: Too many failures, reject requests immediately
    - HALF_OPEN: Testing if service recovered
    """
    
    def __init__(self, failure_threshold=5, timeout=60):
        self.failure_threshold = failure_threshold
        self.timeout = timeout
        self.failures = 0
        self.last_failure_time = None
        self.state = "CLOSED"
    
    def call(self, func, *args, **kwargs):
        if self.state == "OPEN":
            if time.time() - self.last_failure_time > self.timeout:
                logger.info("Circuit breaker: Transitioning to HALF_OPEN")
                self.state = "HALF_OPEN"
            else:
                raise Exception("Circuit breaker is OPEN - service unavailable")
        
        try:
            result = func(*args, **kwargs)
            
            if self.state == "HALF_OPEN":
                logger.info("Circuit breaker: Service recovered, transitioning to CLOSED")
                self.state = "CLOSED"
                self.failures = 0
            
            return result
            
        except Exception as e:
            self.failures += 1
            self.last_failure_time = time.time()
            
            if self.failures >= self.failure_threshold:
                logger.error(f"Circuit breaker: Opening circuit after {self.failures} failures")
                self.state = "OPEN"
            
            raise


# ============================================================================
# DEMO
# ============================================================================

def main():
    print("\n" + "="*70)
    print("Demo 1: Production-Grade API Calls")
    print("="*70 + "\n")
    
    # Demo 1: Basic good practice
    print("1. Fetching single user with good practice:")
    print("-" * 50)
    try:
        user = get_user_good(1)
        print(f"✓ Success! User: {user['name']} ({user['email']})")
    except Exception as e:
        print(f"✗ Failed: {e}")
    
    print("\n")
    
    # Demo 2: Multiple users with partial failure handling
    print("2. Fetching multiple users (including invalid ID):")
    print("-" * 50)
    user_ids = [1, 2, 999, 3]  # 999 doesn't exist
    users = get_multiple_users(user_ids)
    print(f"✓ Fetched {len(users)} users successfully")
    for user in users:
        print(f"  - {user['name']}")
    
    print("\n")
    
    # Demo 3: Timeout demonstration
    print("3. Testing timeout (using a slow endpoint):")
    print("-" * 50)
    try:
        # This endpoint is intentionally slow
        response = session.get(
            "https://httpbin.org/delay/5",  # Delays 5 seconds
            timeout=2  # But we only wait 2 seconds
        )
        print("✓ Request completed")
    except requests.exceptions.Timeout:
        print("✗ Request timed out (as expected)")
    
    print("\n")
    
    # Demo 4: Circuit breaker
    print("4. Circuit breaker demonstration:")
    print("-" * 50)
    circuit_breaker = SimpleCircuitBreaker(failure_threshold=3, timeout=5)
    
    def failing_api_call():
        """Simulates a failing API"""
        raise requests.exceptions.ConnectionError("Service unavailable")
    
    # Try calling the failing service multiple times
    for i in range(5):
        try:
            circuit_breaker.call(failing_api_call)
        except Exception as e:
            print(f"  Attempt {i+1}: {e}")
        time.sleep(0.5)
    
    print("\n" + "="*70)
    print("Demo complete! Check the logs above for details.")
    print("="*70 + "\n")


if __name__ == "__main__":
    main()
