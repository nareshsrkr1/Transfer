import logging
import requests
from requests.adapters import HTTPAdapter, Retry

logger = logging.getLogger(__name__)

session = requests.Session()
retries = Retry(total=3, backoff_factor=0.5)
session.mount("https://", HTTPAdapter(max_retries=retries))

def get_user(user_id: int) -> dict:
    try:
        response = session.get(
            f"{BASE_URL}/users/{user_id}",
            timeout=3
        )
        response.raise_for_status()
        return response.json()
    except Exception as e:
        logger.exception("Failed to fetch user %s", user_id)
        raise

'''
What have been added here 

'''