# AI Application Architecture & How LLMs Work
## Presentation Slides with Speaker Notes

---

## **Slide 1: AI Application Architecture - The Big Picture**

### Slide Content:

```
┌─────────────────────────────────────────────────────────┐
│          AI APPLICATION ARCHITECTURE                     │
└─────────────────────────────────────────────────────────┘

1. USER INTERFACE (Frontend)
   → Web/Mobile App where users interact
   Example: ChatGPT chat box, Google Search

2. APPLICATION LAYER (Backend)
   → Processes requests, handles business logic
   → Manages user sessions and data flow

3. AI/LLM LAYER
   → The "brain" - processes natural language
   → Examples: GPT-4, Claude, Gemini

4. DATA LAYER
   → Vector Databases (for context/memory)
   → Traditional Databases (for user data)
   → Knowledge Bases (company docs, manuals)

5. EXTERNAL INTEGRATIONS
   → APIs, Tools, Plugins
   → Example: Weather API, Calendar, Email
```

**Real-World Example Flow:**
```
User: "Book me a flight to Paris next Friday"
  ↓
UI sends request → Backend processes → LLM understands intent
  ↓
LLM breaks down: [Search flights] + [Check calendar] + [Book ticket]
  ↓
Calls Flight API → Checks your calendar → Returns options
  ↓
Response back to user with flight options
```

---

### Speaker Notes for Slide 1:

**Opening (30 seconds):**
"Let me show you how modern AI applications work. Think of it like a restaurant kitchen - you have different stations working together to serve your order."

**Point 1 - User Interface (20 seconds):**
"The UI is what you see - just like a restaurant menu. It could be a chat window like ChatGPT, or a search box like Google. This is where you type your question or request."

**Point 2 - Application Layer (30 seconds):**
"The backend is like the head chef coordinating everything. When you ask 'What's the weather in New York?', the backend doesn't answer directly - it routes your question to the right place, manages your login session, and makes sure everything flows smoothly."

**Point 3 - AI/LLM Layer (45 seconds):**
"This is the star of the show - the AI brain. Think of it as a super-smart assistant who has read millions of books and can understand what you mean, not just what you say. 

For example, if you type 'I'm cold', a traditional program would just see those words. But an LLM understands you might want:
- Temperature control suggestions
- Clothing recommendations
- Or maybe you're just making conversation

It understands CONTEXT and INTENT."

**Point 4 - Data Layer (40 seconds):**
"Now here's something cool - the AI needs memory. There are two types:

1. **Vector Databases** - Think of this as the AI's short-term memory. It stores your conversation history and relevant documents in a special format that the AI can quickly search through. Like when ChatGPT remembers what you said 5 messages ago.

2. **Traditional Databases** - This stores your account info, settings, and structured data like your name, email, preferences.

Real example: When you ask 'What did we discuss about the project yesterday?', the AI searches its vector database to find that conversation."

**Point 5 - External Integrations (30 seconds):**
"Finally, the AI can use tools - just like you use apps on your phone. It can:
- Check real-time weather via Weather API
- Send emails through Gmail API
- Search the web through Bing API
- Calculate complex math using WolframAlpha

The AI decides WHICH tool to use based on your request."

**Example Walkthrough (45 seconds):**
"Let's trace a real request: 'Book me a flight to Paris next Friday'

1. You type in the UI
2. Backend receives it and sends to the LLM
3. LLM thinks: 'I need to search flights, check their calendar for Friday, and help book'
4. It calls the Flight Search API with parameters (destination: Paris, date: next Friday)
5. Checks your calendar to confirm you're free
6. Returns flight options back through the chain to your screen

All of this happens in 2-3 seconds!"

---

## **Slide 2: How LLMs Work - Under the Hood**

### Slide Content:

```
┌─────────────────────────────────────────────────────────┐
│          HOW LARGE LANGUAGE MODELS WORK                  │
└─────────────────────────────────────────────────────────┘

STEP 1: TRAINING (Learning Phase)
📚 Reads billions of web pages, books, code
🧠 Learns patterns: "After 'Hello', usually comes a greeting"
⚡ Creates a massive neural network (billions of parameters)

STEP 2: TOKENIZATION (Breaking Down Input)
Input: "I love pizza"
Tokens: ["I", "love", "pizza"]
→ Converts words to numbers the AI understands

STEP 3: PREDICTION (Generating Response)
Question: "What is the capital of France?"
  ↓
LLM thinks in probabilities:
  "The" (95%) → "capital" (88%) → "of" (92%) 
  → "France" (94%) → "is" (96%) → "Paris" (99%)
  ↓
Output: "The capital of France is Paris"

STEP 4: CONTEXT WINDOW
Recent conversation stored in memory (e.g., last 128K tokens)
Like remembering the last 100 pages of a book
```

**Simple Analogy:**
```
LLM = Super-Smart Autocomplete
  
Your Phone: "See you tom..." → suggests "tomorrow"
LLM: "Explain quantum..." → predicts entire explanation

Difference: LLM understands MEANING, not just patterns
```

---

### Speaker Notes for Slide 2:

**Opening (20 seconds):**
"Now let's peek under the hood. How does the AI actually 'think'? It's simpler than you might imagine - it's basically the world's most advanced autocomplete!"

**Step 1 - Training (60 seconds):**
"First, the training phase - this happens BEFORE you ever use the AI.

Imagine teaching a child to speak by having them read every book in every library on Earth. That's what happens here. The LLM reads:
- Wikipedia (all of it)
- Millions of books
- Websites, forums, code repositories
- Scientific papers

During this, it learns patterns. For example:
- After 'Once upon a time' usually comes a story
- After 'import' in Python code, comes a library name
- 'Paris' is often mentioned near 'France' and 'Eiffel Tower'

This creates a neural network - think of it as billions of tiny connections, like neurons in your brain. GPT-4 has about 1.7 TRILLION parameters (connections). Each one stores a tiny piece of knowledge."

**Step 2 - Tokenization (45 seconds):**
"When you type something, the AI doesn't see words like we do. It breaks everything into 'tokens' - small chunks.

Example:
- 'I love pizza' → ['I', 'love', 'pizza'] (3 tokens)
- 'ChatGPT' → ['Chat', 'GPT'] (2 tokens)
- 'unbelievable' → ['un', 'believ', 'able'] (3 tokens)

Then it converts these to numbers:
- 'I' → 314
- 'love' → 1891
- 'pizza' → 8428

Why? Because computers work with numbers, not words. It's like translating English to computer language."

**Step 3 - Prediction (90 seconds):**
"Here's the magic - the LLM predicts the next word, one at a time, based on probability.

Let me show you with a real example:

You ask: 'What is the capital of France?'

The LLM thinks:
1. 'What word should come first?' → Scans its training → 'The' has 95% probability
2. 'After The, what comes?' → 'capital' (88% probability)
3. 'After The capital, what next?' → 'of' (92%)
4. 'After The capital of, what?' → 'France' (94%)
5. 'After France?' → 'is' (96%)
6. 'Finally?' → 'Paris' (99%)

Output: 'The capital of France is Paris'

**Important point:** It's not looking up facts in a database! It's predicting based on patterns it learned. It 'knows' Paris is the answer because it saw 'Paris' and 'capital of France' together thousands of times during training.

This is why sometimes it makes mistakes - if it learned wrong patterns, it predicts wrong answers. Like if you learned French from someone with a bad accent, you'd speak with that accent too."

**Step 4 - Context Window (50 seconds):**
"The context window is the AI's short-term memory - how much of the conversation it can remember.

Think of it like this:
- GPT-3.5: Can remember about 4,000 words (like 8 pages)
- GPT-4: Can remember about 128,000 words (like 300 pages of a book)
- Claude: Up to 200,000 words (an entire novel!)

Why does this matter?

Example: You're having a long conversation about planning a wedding. If you ask on message #50, 'What color did we choose for flowers?', the AI needs to remember message #12 where you said 'pink roses'. 

If that's outside the context window, it'll say 'I don't recall' - because it literally forgot. It's like asking someone about a conversation from 5 years ago."

**Analogy Explanation (45 seconds):**
"Here's the simplest way to think about it:

Your phone's autocomplete:
- You type 'See you tom...'
- It suggests 'tomorrow'
- Based on: you've typed this before

LLM is the same, but MASSIVELY more powerful:
- You type 'Explain quantum computing...'
- It predicts an entire explanation
- Based on: reading thousands of quantum physics articles

The key difference? 

Your phone just matches patterns: 'tom' → 'tomorrow'

LLM understands meaning: 'Explain' = you want education, 'quantum computing' = complex physics topic, so it should give a clear, beginner-friendly explanation with examples.

It's like the difference between a parrot repeating words and a teacher who actually understands what they're teaching."

**Closing (30 seconds):**
"So to recap: LLMs are trained on massive amounts of text, they break your input into tokens, predict responses word-by-word using probability, and remember recent conversation in their context window. 

They're incredibly powerful, but they're not magic - they're pattern-matching machines that got REALLY good at understanding language patterns. That's why they can write code, answer questions, and have conversations - because they learned the patterns of how humans do all these things!"

---

## **Quick Reference: Key Takeaways**

### AI Application Architecture:
- **5 Layers**: UI → Backend → AI → Data → External Tools
- **Real Example**: Flight booking uses all 5 layers working together
- **Key Insight**: AI is just one part; the architecture makes it useful

### How LLMs Work:
- **Training**: Learn from billions of text examples
- **Tokenization**: Convert words to numbers
- **Prediction**: Guess next word using probability
- **Context Window**: Short-term memory of conversation
- **Simple Analogy**: Super-smart autocomplete that understands meaning

---

## **Bonus: Common Questions & Answers**

**Q: "Does the LLM have access to the internet?"**
A: Not by default! It only knows what it learned during training (which has a cutoff date). To get real-time info, the application layer must call external APIs (like Google Search API) and feed results back to the LLM.

**Q: "Why does it sometimes make up facts?"**
A: Because it's predicting based on patterns, not looking up facts. If it learned incorrect patterns, or if it's asked about something rare, it might "hallucinate" - confidently predict something that sounds right but isn't true.

**Q: "How is this different from Google Search?"**
A: Google finds existing web pages matching your keywords. LLM generates NEW text by predicting word-by-word. Google is like a librarian finding books; LLM is like a writer creating a new book based on everything it's read.

**Q: "Can I train my own LLM?"**
A: Training from scratch costs millions of dollars and requires massive computing power. But you can "fine-tune" an existing LLM on your specific data (like your company's documents) for much cheaper - this is what most businesses do.

---

## **Slide 3: RAG & Prompt Patterns - Making AI Smarter**

### Slide Content:

```
┌─────────────────────────────────────────────────────────┐
│     RAG (Retrieval-Augmented Generation)                │
└─────────────────────────────────────────────────────────┘

THE PROBLEM:
❌ LLMs only know what they learned during training
❌ No access to your company docs, recent data, or private info
❌ Can't answer: "What's in our Q4 sales report?"

THE SOLUTION: RAG
✅ Fetch relevant information FIRST
✅ Give it to the LLM as context
✅ LLM generates answer using that info

HOW RAG WORKS:
┌─────────────────────────────────────────────────┐
│ 1. User Question                                │
│    "What was our revenue last quarter?"         │
│         ↓                                       │
│ 2. Search Vector Database                       │
│    Find relevant docs: [Q4_Report.pdf]          │
│         ↓                                       │
│ 3. Retrieve Context                             │
│    "Q4 revenue: $2.5M, up 15%..."              │
│         ↓                                       │
│ 4. Combine Question + Context                   │
│    Send both to LLM                             │
│         ↓                                       │
│ 5. LLM Generates Answer                         │
│    "Last quarter revenue was $2.5M..."         │
└─────────────────────────────────────────────────┘

PROMPT PATTERNS (How to ask AI effectively):

1. ZERO-SHOT (No examples)
   "Translate this to French: Hello"

2. FEW-SHOT (Give examples)
   "Translate to French:
    English: Hello → French: Bonjour
    English: Thank you → French: Merci
    English: Goodbye → French: ?"

3. CHAIN-OF-THOUGHT (Think step-by-step)
   "Solve: 25 × 4 = ?
    Let's think step by step:
    1. Break down: 25 × 4
    2. 25 × 2 = 50
    3. 50 × 2 = 100"

4. ROLE-BASED (Set persona)
   "You are a Python expert. Review this code..."
```

**Real Example - Customer Support Bot:**
```
Without RAG:
User: "What's your return policy?"
AI: "I don't have access to specific company policies."

With RAG:
User: "What's your return policy?"
  → System searches knowledge base
  → Finds: "30-day return policy document"
  → Sends to AI with question
AI: "We offer a 30-day return policy. Items must be..."
```

---

### Speaker Notes for Slide 3:

**Opening (20 seconds):**
"Now let's talk about two game-changers: RAG and Prompt Patterns. These are what make AI actually useful in real business applications."

---

#### **PART 1: RAG (Retrieval-Augmented Generation)**

**The Problem (45 seconds):**
"Remember, LLMs only know what they learned during training. GPT-4's training data cuts off in April 2023. So if you ask:
- 'What happened in the news today?' → It doesn't know
- 'What's in our company's Q4 sales report?' → It doesn't know
- 'What's my account balance?' → It doesn't know

This is a HUGE limitation. Imagine hiring a super-smart consultant who hasn't read any of your company documents. Not very useful, right?

That's where RAG comes in."

**The Solution - RAG Explained (90 seconds):**
"RAG stands for Retrieval-Augmented Generation. Big words, simple concept:

**Think of it like an open-book exam:**
- Without RAG: AI answers from memory only (closed-book test)
- With RAG: AI can look up information first, then answer (open-book test)

Here's the flow:

**Step 1:** User asks a question: 'What was our revenue last quarter?'

**Step 2:** Before sending to the LLM, the system searches your vector database (remember from Slide 1?) for relevant documents. It finds: 'Q4_Financial_Report.pdf'

**Step 3:** It extracts the relevant section: 'Q4 2025 Revenue: $2.5M, representing 15% growth...'

**Step 4:** Now it creates a SUPER-PROMPT combining both:
```
Context: Q4 2025 Revenue: $2.5M, representing 15% growth...
Question: What was our revenue last quarter?
Answer based ONLY on the context provided.
```

**Step 5:** LLM reads the context and generates: 'Last quarter's revenue was $2.5 million, showing a 15% increase...'

The magic? The LLM doesn't need to 'know' your Q4 numbers. It just needs to read and summarize what you gave it!"

**Real-World RAG Example (60 seconds):**
"Let me give you a concrete example - a customer support chatbot:

**Without RAG:**
```
Customer: 'What's your return policy?'
AI: 'I don't have access to specific company policies. Please check our website.'
```
Useless, right?

**With RAG:**
```
Customer: 'What's your return policy?'

Behind the scenes:
1. System searches knowledge base
2. Finds document: 'Return_Policy_2025.pdf'
3. Extracts: 'We offer a 30-day return policy. Items must be unused with original packaging...'
4. Sends to LLM with question

AI: 'We offer a 30-day return policy. Items must be unused and in original packaging. You can initiate returns through your account or by contacting support at...'
```

Now THAT'S useful! The AI is answering from your actual company policy, not making things up.

**Real companies using RAG:**
- **Notion AI**: Searches your workspace docs before answering
- **ChatGPT with file upload**: Reads your PDF before answering questions
- **Enterprise chatbots**: Search company knowledge bases"

**Key Insight (20 seconds):**
"RAG is why AI can suddenly 'know' about your private data without expensive retraining. You're not teaching it new facts - you're giving it a library to reference!"

---

#### **PART 2: Prompt Patterns**

**Introduction (30 seconds):**
"Now, how you ASK the AI matters just as much as what you ask. This is called 'prompt engineering.' Let me show you four powerful patterns that dramatically improve AI responses."

**Pattern 1: Zero-Shot (30 seconds):**
"This is the simplest - just ask directly, no examples.

```
'Translate this to French: Hello'
```

Works great for common tasks the AI has seen millions of times during training. But for complex or specific tasks, you need more..."

**Pattern 2: Few-Shot Learning (75 seconds):**
"This is POWERFUL. You give the AI examples of what you want, then ask your question.

**Example - Teaching AI your company's tone:**

Bad (zero-shot):
```
'Write a customer email about a delayed order'
AI: 'Dear Customer, We regret to inform you...' (too formal)
```

Good (few-shot):
```
'Write emails in our company style:

Example 1:
Issue: Shipping delay
Email: Hey! Quick heads up - your order is running a day late. We're on it! 🚀

Example 2:
Issue: Out of stock
Email: Oops! That item just sold out. Want us to notify you when it's back?

Now write:
Issue: Delayed order
Email: ?'

AI: 'Hey! Your order hit a small snag and will arrive 2 days late. We're really sorry about that! 🙏'
```

See the difference? The AI learned your casual, friendly tone from examples.

**Another example - Data extraction:**
```
Extract info in this format:
'Name: John, Age: 25, City: NYC' → {name: 'John', age: 25, city: 'NYC'}
'Name: Sarah, Age: 30, City: LA' → {name: 'Sarah', age: 30, city: 'LA'}
'Name: Mike, Age: 28, City: Boston' → ?

AI: {name: 'Mike', age: 28, city: 'Boston'}
```

The AI learns the pattern from your examples!"

**Pattern 3: Chain-of-Thought (75 seconds):**
"This is for complex reasoning. You ask the AI to 'think step-by-step.'

**Example - Math problem:**

Without CoT:
```
'What's 47 × 23?'
AI: '1081' (might be right, might be wrong, you don't know how it got there)
```

With CoT:
```
'What's 47 × 23? Let's solve step-by-step:'

AI: 
'Let me break this down:
1. 47 × 20 = 940
2. 47 × 3 = 141
3. 940 + 141 = 1081
Answer: 1081'
```

Now you can verify the logic!

**Real business example - Debugging code:**

Without CoT:
```
'Why is this code failing?'
AI: 'Change line 5 to...' (no explanation)
```

With CoT:
```
'Debug this code. Think through it step-by-step:'

AI:
'Let me analyze:
1. Line 3: Variable 'user' is defined
2. Line 5: Trying to access 'user.name'
3. Problem: 'user' could be None if database query fails
4. Line 5 will crash with AttributeError
5. Solution: Add null check before accessing properties'
```

Much better! You understand the WHY, not just the fix."

**Pattern 4: Role-Based Prompting (45 seconds):**
"Tell the AI WHO to be, and it adjusts its expertise and tone.

**Example:**

Generic:
```
'Review this Python code'
AI: 'Looks okay' (vague)
```

Role-based:
```
'You are a senior Python developer who values clean code and performance. Review this:'

AI: 'Issues found:
1. Line 12: Using list comprehension would be 3x faster
2. Line 18: This variable name violates PEP 8
3. Missing docstrings for public methods
4. Consider using dataclasses instead of dict for type safety'
```

**Other useful roles:**
- 'You are a 5-year-old' → Explains in simple terms
- 'You are a technical writer' → Clear documentation
- 'You are a security expert' → Finds vulnerabilities
- 'You are a skeptical reviewer' → Challenges assumptions"

**Combining Patterns (30 seconds):**
"The real power? Combine these patterns!

```
'You are a Python expert. Here are examples of our code style:
[few-shot examples]

Now review this code step-by-step:
[code]

Think through: correctness, performance, style.'
```

This uses: Role-based + Few-shot + Chain-of-thought. Super powerful!"

---

**Closing (30 seconds):**
"To recap:
- **RAG**: Give AI access to your private data by retrieving relevant docs first
- **Prompt Patterns**: How you ask determines quality of answers
  - Zero-shot: Direct questions
  - Few-shot: Learn from examples
  - Chain-of-thought: Step-by-step reasoning
  - Role-based: Set expertise level

Master these, and you'll get 10x better AI responses!"

---

## **Slide 4: AI Agents & Integration - Building Production-Ready AI Systems**

### Slide Content:

```
┌─────────────────────────────────────────────────────────┐
│          AGENTIC WORKFLOW PATTERN                       │
└─────────────────────────────────────────────────────────┘

STEP 1: PLANNING (Task Decomposition)
  → LLM analyzes request and breaks into sub-tasks
  → Selects appropriate tools/APIs to use
  → Determines execution order (sequential/parallel)

STEP 2: EXECUTION (Tool Orchestration)
  → Calls external APIs, databases, functions
  → Handles responses and errors
  → Maintains state across tool calls

STEP 3: REFLECTION (Self-Correction)
  → Validates results against requirements
  → Re-plans if goals not met
  → Iterates until success or max attempts

STEP 4: RESPONSE (Result Synthesis)
  → Aggregates data from all tool calls
  → Formats output for user
  → Provides actionable recommendations

┌─────────────────────────────────────────────────────────┐
│          INTEGRATION PATTERNS                           │
└─────────────────────────────────────────────────────────┘

1. FUNCTION CALLING (OpenAI/Anthropic)
   → Define functions as JSON schemas
   → LLM decides when to call them
   → Your code executes the function
   → Return result to LLM for synthesis

2. TOOL USE (LangChain/LlamaIndex)
   → Wrap APIs/functions as "tools"
   → Agent autonomously chains tool calls
   → Built-in retry logic and error handling

3. REACT PATTERN (Reasoning + Acting)
   → Thought: "I need to check the database"
   → Action: call_database(query)
   → Observation: [results]
   → Repeat until task complete
```

**Real Example - Travel Booking Agent:**
```python
# Example: OpenAI Function Calling Pattern
from openai import OpenAI

client = OpenAI()

# Define available tools/functions
tools = [
    {
        "type": "function",
        "function": {
            "name": "search_flights",
            "description": "Search for flights to a destination",
            "parameters": {
                "type": "object",
                "properties": {
                    "destination": {"type": "string"},
                    "date": {"type": "string", "format": "date"},
                    "max_price": {"type": "number"}
                },
                "required": ["destination", "date"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "search_hotels",
            "description": "Search for hotels in a city",
            "parameters": {
                "type": "object",
                "properties": {
                    "city": {"type": "string"},
                    "max_price": {"type": "number"},
                    "near": {"type": "string"}
                },
                "required": ["city"]
            }
        }
    }
]

# Agent workflow
messages = [{"role": "user", "content": "Find me a flight to Paris on Feb 2 and a hotel under $200 near museums"}]

response = client.chat.completions.create(
    model="gpt-4",
    messages=messages,
    tools=tools,
    tool_choice="auto"  # Let LLM decide which tools to use
)

# LLM decides to call functions
tool_calls = response.choices[0].message.tool_calls

for tool_call in tool_calls:
    if tool_call.function.name == "search_flights":
        # Execute actual function
        result = search_flights(**json.loads(tool_call.function.arguments))
        messages.append({
            "role": "tool",
            "tool_call_id": tool_call.id,
            "content": json.dumps(result)
        })
```

**LangChain Agent Example:**
```python
from langchain.agents import initialize_agent, Tool
from langchain.llms import OpenAI

# Define tools
tools = [
    Tool(
        name="FlightSearch",
        func=search_flights,
        description="Search flights. Input: {destination, date, max_price}"
    ),
    Tool(
        name="HotelSearch",
        func=search_hotels,
        description="Search hotels. Input: {city, max_price, near}"
    ),
    Tool(
        name="WeatherAPI",
        func=get_weather,
        description="Get weather forecast. Input: {city, date}"
    )
]

# Initialize agent with ReAct pattern
agent = initialize_agent(
    tools=tools,
    llm=OpenAI(temperature=0),
    agent="zero-shot-react-description",
    verbose=True,
    max_iterations=5
)

# Agent autonomously plans and executes
result = agent.run("Plan a trip to Paris on Feb 2, find hotel under $200 near museums")

# Output shows reasoning:
# Thought: I need to search for flights first
# Action: FlightSearch
# Action Input: {"destination": "Paris", "date": "2026-02-02"}
# Observation: [flight results]
# Thought: Now I need to find hotels
# Action: HotelSearch
# ...
```

---

### Speaker Notes for Slide 4:

**Opening (30 seconds):**
"Let's dive into how to actually build AI agents in production. I'll show you the workflow pattern that powers modern AI systems, then we'll look at three integration patterns with real code you can use today."

---

#### **PART 1: Agentic Workflow Pattern**

**Overview (20 seconds):**
"Every production AI agent follows this 4-phase pattern. Understanding this helps you debug issues and optimize performance."

**Phase 1: Planning - Task Decomposition (60 seconds):**
"The LLM analyzes the user request and breaks it into actionable sub-tasks.

**Example request:** 'Find me a flight to Paris on Feb 2 and a hotel under $200 near museums'

**LLM's internal reasoning:**
```
Task decomposition:
1. Parse date: 'Feb 2' → Need to resolve to actual date (2026-02-02)
2. Search flights: destination=Paris, date=2026-02-02
3. Search hotels: city=Paris, max_price=200, near='museums'
4. Get weather: city=Paris, date=2026-02-02 (helpful context)

Execution plan:
- Step 1 must run first (date resolution)
- Steps 2, 3, 4 can run in parallel (no dependencies)
```

**Key insight:** The LLM determines this plan autonomously based on the function descriptions you provide. Better descriptions = better planning.

**Pro tip:** For complex workflows, use a dedicated 'planning' LLM call before execution:
```python
planning_prompt = f'''
Given this request: {user_request}
Available tools: {tool_descriptions}
Create an execution plan with dependencies.
'''
plan = llm.generate(planning_prompt)
```

This gives you more control and makes debugging easier."

**Phase 2: Execution - Tool Orchestration (90 seconds):**
"This is where the agent calls your functions/APIs.

**Sequential vs Parallel execution:**

```python
# Sequential (when there are dependencies)
date = resolve_date('Feb 2')  # Must run first
flights = search_flights(destination='Paris', date=date)  # Uses date
hotel = search_hotels(city='Paris', near='museums')  # Independent

# Parallel (when no dependencies)
import asyncio

async def execute_parallel():
    results = await asyncio.gather(
        search_flights_async('Paris', '2026-02-02'),
        search_hotels_async('Paris', max_price=200),
        get_weather_async('Paris', '2026-02-02')
    )
    return results

# 3x faster than sequential!
```

**State management across tool calls:**

The agent needs to maintain context. Two approaches:

1. **Stateless (function calling):** Each tool call is independent, LLM manages state in message history
```python
messages = [
    {"role": "user", "content": "Find flights to Paris"},
    {"role": "assistant", "tool_calls": [...]},
    {"role": "tool", "content": flight_results},
    {"role": "assistant", "content": "I found 3 flights..."},
    {"role": "user", "content": "Book the cheapest one"}  # LLM remembers from history
]
```

2. **Stateful (agent frameworks):** Agent maintains a memory object
```python
from langchain.memory import ConversationBufferMemory

memory = ConversationBufferMemory()
agent = initialize_agent(tools, llm, memory=memory)

agent.run("Find flights to Paris")  # Stores in memory
agent.run("Book the cheapest one")  # Retrieves from memory
```

**Error handling in execution:**
```python
def execute_tool_with_retry(tool_call, max_retries=3):
    for attempt in range(max_retries):
        try:
            result = execute_tool(tool_call)
            return result
        except APITimeout:
            if attempt < max_retries - 1:
                time.sleep(2 ** attempt)  # Exponential backoff
                continue
            else:
                return {"error": "API timeout after 3 retries"}
        except Exception as e:
            return {"error": str(e)}
```

The LLM can then decide how to handle the error in the reflection phase."

**Phase 3: Reflection - Self-Correction (75 seconds):**
"This is what separates good agents from great ones. The agent validates its work and retries if needed.

**Basic reflection pattern:**
```python
def agent_loop(user_request, max_iterations=5):
    messages = [{"role": "user", "content": user_request}]
    
    for iteration in range(max_iterations):
        # Get LLM response
        response = llm.chat(messages, tools=tools)
        
        # If no tool calls, LLM thinks it's done
        if not response.tool_calls:
            return response.content
        
        # Execute tool calls
        for tool_call in response.tool_calls:
            result = execute_tool(tool_call)
            messages.append({
                "role": "tool",
                "content": json.dumps(result)
            })
        
        # LLM reflects on results and decides next action
        # Loop continues until LLM returns final answer
    
    return "Max iterations reached"
```

**Advanced reflection with validation:**
```python
def validate_results(user_request, tool_results):
    validation_prompt = f'''
    User requested: {user_request}
    Results obtained: {tool_results}
    
    Check if requirements are met:
    - Are all required fields present?
    - Do results match constraints (price, location, etc.)?
    - Is any information missing?
    
    Return: {{"valid": true/false, "missing": [...], "next_action": "..."}}
    '''
    
    validation = llm.generate(validation_prompt)
    return json.loads(validation)

# In agent loop
validation = validate_results(user_request, tool_results)
if not validation['valid']:
    # Re-plan with missing requirements
    messages.append({
        "role": "system",
        "content": f"Previous attempt incomplete. Missing: {validation['missing']}. Try: {validation['next_action']}"
    })
    continue  # Next iteration
```

**Real example - GitHub Copilot Workspace:**
When it generates code, it:
1. Writes the code
2. Runs tests
3. If tests fail, analyzes error messages
4. Fixes the code
5. Re-runs tests
6. Repeats until tests pass or max attempts

All autonomous!"

**Phase 4: Response - Result Synthesis (30 seconds):**
"Finally, aggregate all data into a user-friendly response.

```python
def synthesize_response(tool_results):
    synthesis_prompt = f'''
    Tool results:
    - Flights: {tool_results['flights']}
    - Hotels: {tool_results['hotels']}
    - Weather: {tool_results['weather']}
    
    Create a concise, actionable summary for the user.
    Include: best options, total cost, helpful tips.
    '''
    
    return llm.generate(synthesis_prompt)
```

The LLM naturally formats this in a human-friendly way, adding context and recommendations."

---

#### **PART 2: Integration Patterns**

**Introduction (15 seconds):**
"Now let's look at three production-ready patterns for integrating LLMs into your applications."

**Pattern 1: Function Calling (OpenAI/Anthropic) (120 seconds):**
"This is the most common pattern. You define functions as JSON schemas, the LLM decides when to call them.

**Complete example:**

```python
from openai import OpenAI
import json

client = OpenAI(api_key="your-key")

# Step 1: Define your actual functions
def get_current_weather(location: str, unit: str = "celsius"):
    # In production, call actual weather API
    return {
        "location": location,
        "temperature": 22,
        "unit": unit,
        "forecast": "sunny"
    }

def search_database(query: str):
    # In production, query your database
    return {
        "results": [
            {"id": 1, "name": "Product A", "price": 99},
            {"id": 2, "name": "Product B", "price": 149}
        ]
    }

# Step 2: Define function schemas for LLM
tools = [
    {
        "type": "function",
        "function": {
            "name": "get_current_weather",
            "description": "Get the current weather in a location. Use this when user asks about weather.",
            "parameters": {
                "type": "object",
                "properties": {
                    "location": {
                        "type": "string",
                        "description": "City name, e.g. San Francisco"
                    },
                    "unit": {
                        "type": "string",
                        "enum": ["celsius", "fahrenheit"],
                        "description": "Temperature unit"
                    }
                },
                "required": ["location"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "search_database",
            "description": "Search products in database. Use when user asks about products or inventory.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search query"
                    }
                },
                "required": ["query"]
            }
        }
    }
]

# Step 3: Agent loop
def run_agent(user_message):
    messages = [{"role": "user", "content": user_message}]
    
    # Map function names to actual functions
    available_functions = {
        "get_current_weather": get_current_weather,
        "search_database": search_database
    }
    
    while True:
        # Call LLM
        response = client.chat.completions.create(
            model="gpt-4",
            messages=messages,
            tools=tools,
            tool_choice="auto"
        )
        
        response_message = response.choices[0].message
        messages.append(response_message)
        
        # Check if LLM wants to call functions
        if not response_message.tool_calls:
            # No more function calls, return final answer
            return response_message.content
        
        # Execute each function call
        for tool_call in response_message.tool_calls:
            function_name = tool_call.function.name
            function_args = json.loads(tool_call.function.arguments)
            
            # Call the actual function
            function_response = available_functions[function_name](**function_args)
            
            # Add function result to messages
            messages.append({
                "role": "tool",
                "tool_call_id": tool_call.id,
                "name": function_name,
                "content": json.dumps(function_response)
            })
        
        # Loop continues - LLM will process results and either call more functions or return answer

# Usage
result = run_agent("What's the weather in Paris and show me products under $100")
print(result)
```

**Key points:**
- **Descriptions matter:** The LLM uses descriptions to decide when to call functions. Be specific!
- **Type safety:** Use proper JSON schema types to avoid parsing errors
- **Error handling:** Wrap function calls in try/except and return errors as JSON
- **Cost optimization:** Each loop iteration costs tokens. Set `max_iterations` to prevent runaway costs."

**Pattern 2: LangChain/LlamaIndex Agents (90 seconds):**
"These frameworks provide higher-level abstractions with built-in retry logic, memory, and more.

**LangChain example:**

```python
from langchain.agents import initialize_agent, Tool, AgentType
from langchain.chat_models import ChatOpenAI
from langchain.memory import ConversationBufferMemory

# Define tools (simpler than OpenAI function calling)
def calculator(expression: str) -> str:
    try:
        return str(eval(expression))
    except:
        return "Invalid expression"

def search_docs(query: str) -> str:
    # Search your vector database
    results = vector_db.similarity_search(query, k=3)
    return "\\n".join([doc.page_content for doc in results])

tools = [
    Tool(
        name="Calculator",
        func=calculator,
        description="Useful for math calculations. Input should be a valid Python expression like '2+2' or '10*5'"
    ),
    Tool(
        name="DocumentSearch",
        func=search_docs,
        description="Search company documentation. Input should be a search query."
    )
]

# Initialize agent with memory
llm = ChatOpenAI(model="gpt-4", temperature=0)
memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)

agent = initialize_agent(
    tools=tools,
    llm=llm,
    agent=AgentType.CHAT_CONVERSATIONAL_REACT_DESCRIPTION,
    memory=memory,
    verbose=True,  # Shows reasoning steps
    max_iterations=5,
    early_stopping_method="generate"
)

# Use the agent
response = agent.run("What's 25 * 47? Then search our docs for return policy.")

# Agent automatically:
# 1. Calls Calculator tool
# 2. Calls DocumentSearch tool
# 3. Synthesizes both results
# 4. Remembers conversation in memory
```

**Advantages:**
- Built-in retry logic and error handling
- Memory management out of the box
- Verbose mode for debugging
- Easy to swap LLM providers

**Disadvantages:**
- Less control than raw function calling
- Abstraction can hide issues
- Framework lock-in"

**Pattern 3: ReAct (Reasoning + Acting) (75 seconds):**
"This is the pattern that powers most agents. The LLM alternates between reasoning (thought) and acting (tool use).

**How it works:**

```
Thought: I need to find the user's order first
Action: search_database
Action Input: {"query": "order_id=12345"}
Observation: {"status": "shipped", "tracking": "ABC123"}

Thought: Now I have the tracking number, I should check shipping status
Action: check_shipping_status
Action Input: {"tracking_number": "ABC123"}
Observation: {"status": "in_transit", "eta": "2026-02-05"}

Thought: I have all the information needed
Final Answer: Your order #12345 is in transit and will arrive on Feb 5. Tracking: ABC123
```

**Implementation:**

```python
def react_agent(user_query, tools, max_steps=10):
    prompt_template = '''
    Answer the following question: {query}
    
    You have access to these tools:
    {tool_descriptions}
    
    Use this format:
    Thought: [your reasoning]
    Action: [tool name]
    Action Input: [tool input as JSON]
    Observation: [tool result]
    ... (repeat Thought/Action/Observation as needed)
    Thought: I now know the final answer
    Final Answer: [your answer]
    
    Previous steps:
    {history}
    
    Begin!
    '''
    
    history = []
    
    for step in range(max_steps):
        # Generate next thought/action
        prompt = prompt_template.format(
            query=user_query,
            tool_descriptions=format_tools(tools),
            history="\\n".join(history)
        )
        
        response = llm.generate(prompt)
        
        # Parse response
        if "Final Answer:" in response:
            return response.split("Final Answer:")[1].strip()
        
        # Extract action and input
        action = extract_action(response)  # Parse "Action: tool_name"
        action_input = extract_action_input(response)  # Parse "Action Input: {...}"
        
        # Execute tool
        observation = execute_tool(action, action_input)
        
        # Add to history
        history.append(f"Thought: {extract_thought(response)}")
        history.append(f"Action: {action}")
        history.append(f"Action Input: {action_input}")
        history.append(f"Observation: {observation}")
    
    return "Max steps reached without final answer"
```

**Why ReAct is powerful:**
- **Transparency:** You can see the agent's reasoning
- **Debuggability:** Easy to identify where it went wrong
- **Controllability:** You can inject constraints in the prompt

**Production tip:** Log all Thought/Action/Observation steps for debugging and monitoring."

---

**Real-World Production Considerations (90 seconds):**

"Let me share some lessons from production deployments:

**1. Cost Management:**
```python
# Track token usage
def run_agent_with_tracking(user_query):
    total_tokens = 0
    max_tokens = 10000  # Budget limit
    
    for iteration in agent_loop(user_query):
        total_tokens += iteration.usage.total_tokens
        
        if total_tokens > max_tokens:
            return "Query too complex, exceeded token budget"
    
    log_cost(total_tokens, cost_per_token=0.00003)  # GPT-4 pricing
```

**2. Latency Optimization:**
```python
# Parallel tool execution
async def execute_tools_parallel(tool_calls):
    tasks = [execute_tool_async(tc) for tc in tool_calls]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    return results

# Streaming responses
def stream_agent_response(user_query):
    for chunk in client.chat.completions.create(
        model="gpt-4",
        messages=messages,
        stream=True
    ):
        yield chunk.choices[0].delta.content
```

**3. Security:**
```python
# Validate tool inputs
def validate_tool_input(tool_name, args):
    # Prevent SQL injection
    if tool_name == "search_database":
        if "DROP" in args['query'].upper() or "DELETE" in args['query'].upper():
            raise SecurityError("Potentially dangerous query")
    
    # Prevent file system access
    if tool_name == "read_file":
        if ".." in args['path'] or args['path'].startswith("/"):
            raise SecurityError("Path traversal attempt")
    
    return True

# Rate limiting
from functools import lru_cache
import time

@lru_cache(maxsize=1000)
def rate_limit(user_id: str):
    # Allow 10 requests per minute per user
    # Implementation depends on your stack (Redis, etc.)
    pass
```

**4. Monitoring:**
```python
# Log everything for debugging
import logging

logging.info({
    "user_id": user_id,
    "query": user_query,
    "tools_called": [tc.function.name for tc in tool_calls],
    "total_tokens": total_tokens,
    "latency_ms": latency,
    "success": success
})

# Alert on failures
if error_rate > 0.05:  # 5% error rate
    send_alert("Agent error rate high")
```

**5. Testing:**
```python
# Unit test tools
def test_search_database():
    result = search_database("test query")
    assert "results" in result
    assert isinstance(result["results"], list)

# Integration test agent
def test_agent_workflow():
    response = run_agent("Find products under $100")
    assert "product" in response.lower()
    assert "$" in response  # Should mention price
```

---

**Closing (45 seconds):**
"To recap for production AI agents:

**Workflow Pattern:**
1. Planning - LLM decomposes tasks
2. Execution - Parallel/sequential tool calls
3. Reflection - Validate and retry
4. Response - Synthesize results

**Integration Patterns:**
1. **Function Calling** - Most control, OpenAI/Anthropic native
2. **LangChain/LlamaIndex** - Higher-level, batteries included
3. **ReAct** - Transparent reasoning, great for debugging

**Production Checklist:**
- ✓ Cost tracking and budgets
- ✓ Latency optimization (parallel execution, streaming)
- ✓ Security (input validation, rate limiting)
- ✓ Monitoring and alerting
- ✓ Comprehensive testing

Start with function calling for maximum control, move to frameworks as you scale. Always log reasoning steps for debugging!"
