"""
Example 8: Prompt Patterns
===========================
Simple demonstration of different prompting techniques.
"""

# ============================================================================
# SIMULATED LLM
# ============================================================================

class SimpleLLM:
    """Simulated LLM for demonstration"""
    
    def generate(self, prompt: str) -> str:
        """Generate response based on prompt pattern"""
        prompt_lower = prompt.lower()
        
        # Detect pattern and respond accordingly
        if "translate" in prompt_lower and "bonjour" in prompt_lower:
            # Few-shot detected
            return "Au revoir"
        elif "translate" in prompt_lower and "hello" in prompt_lower:
            # Zero-shot
            return "Bonjour"
        elif "step by step" in prompt_lower:
            # Chain-of-thought
            return """Let me solve this step by step:
1. 25 × 2 = 50
2. 50 × 2 = 100
Answer: 100"""
        elif "python expert" in prompt_lower:
            # Role-based
            return """As a Python expert, I notice:
1. Missing type hints
2. No error handling
3. Variable names could be more descriptive
Recommendation: Add try-except and use meaningful names."""
        else:
            return "I'll help with that!"


# ============================================================================
# PROMPT PATTERNS
# ============================================================================

def zero_shot_example():
    """Pattern 1: Zero-Shot (No examples)"""
    print("1️⃣  ZERO-SHOT (Direct Question)")
    print("-" * 70)
    
    prompt = "Translate this to French: Hello"
    print(f"Prompt:\n{prompt}\n")
    
    llm = SimpleLLM()
    response = llm.generate(prompt)
    print(f"Response:\n{response}\n")
    
    print("When to use: Common tasks LLM has seen many times\n")


def few_shot_example():
    """Pattern 2: Few-Shot (Give examples)"""
    print("2️⃣  FEW-SHOT (Learning from Examples)")
    print("-" * 70)
    
    prompt = """Translate to French:
English: Hello → French: Bonjour
English: Thank you → French: Merci
English: Goodbye → French: ?"""
    
    print(f"Prompt:\n{prompt}\n")
    
    llm = SimpleLLM()
    response = llm.generate(prompt)
    print(f"Response:\n{response}\n")
    
    print("When to use: Teaching LLM your specific format/style\n")


def chain_of_thought_example():
    """Pattern 3: Chain-of-Thought (Step-by-step reasoning)"""
    print("3️⃣  CHAIN-OF-THOUGHT (Think Step by Step)")
    print("-" * 70)
    
    prompt = """Solve: 25 × 4 = ?
Let's think step by step:"""
    
    print(f"Prompt:\n{prompt}\n")
    
    llm = SimpleLLM()
    response = llm.generate(prompt)
    print(f"Response:\n{response}\n")
    
    print("When to use: Complex reasoning, math, debugging\n")


def role_based_example():
    """Pattern 4: Role-Based (Set expertise)"""
    print("4️⃣  ROLE-BASED (Set Persona)")
    print("-" * 70)
    
    code = """
def calc(x, y):
    return x + y
"""
    
    prompt = f"""You are a senior Python expert who values clean code.
Review this code:
{code}"""
    
    print(f"Prompt:\n{prompt}\n")
    
    llm = SimpleLLM()
    response = llm.generate(prompt)
    print(f"Response:\n{response}\n")
    
    print("When to use: Need specific expertise level or tone\n")


# ============================================================================
# COMBINING PATTERNS
# ============================================================================

def combined_example():
    """Combining multiple patterns"""
    print("5️⃣  COMBINING PATTERNS (Maximum Power)")
    print("-" * 70)
    
    prompt = """You are a Python expert. (ROLE-BASED)

Here are examples of our code style: (FEW-SHOT)
Example 1:
def get_user(user_id: int) -> dict:
    \"\"\"Fetch user by ID\"\"\"
    return db.query(user_id)

Example 2:
def create_order(order_data: dict) -> Order:
    \"\"\"Create new order\"\"\"
    return Order.create(order_data)

Now review this code step by step: (CHAIN-OF-THOUGHT)
def process(data):
    result = do_something(data)
    return result

Think through: naming, types, documentation."""
    
    print(f"Prompt:\n{prompt}\n")
    print("Response: [Would provide detailed, step-by-step review in our style]\n")
    
    print("Power: Combines role + examples + reasoning\n")


# ============================================================================
# DEMO
# ============================================================================

def main():
    print("\n" + "="*70)
    print("Demo: Prompt Engineering Patterns")
    print("="*70 + "\n")
    
    zero_shot_example()
    few_shot_example()
    chain_of_thought_example()
    role_based_example()
    combined_example()
    
    print("="*70)
    print("Pattern Selection Guide:")
    print("  • Zero-Shot:         Common tasks, quick answers")
    print("  • Few-Shot:          Custom formats, specific styles")
    print("  • Chain-of-Thought:  Complex reasoning, show work")
    print("  • Role-Based:        Set expertise level/tone")
    print("  • Combined:          Maximum quality (but more tokens)")
    print("\nPro Tips:")
    print("  • Be specific in instructions")
    print("  • Give examples when possible")
    print("  • Ask for step-by-step for complex tasks")
    print("  • Set role for consistent tone")
    print("="*70 + "\n")


if __name__ == "__main__":
    main()
