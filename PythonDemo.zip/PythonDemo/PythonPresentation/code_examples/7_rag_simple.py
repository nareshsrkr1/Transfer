"""
Example 7: RAG (Retrieval-Augmented Generation)
================================================
Simple demonstration of how RAG works.
"""

# ============================================================================
# SIMULATED KNOWLEDGE BASE
# ============================================================================

KNOWLEDGE_BASE = {
    "return_policy.txt": """
    Our Return Policy:
    - 30-day return window
    - Items must be unused and in original packaging
    - Refund processed within 5-7 business days
    - Free return shipping for defective items
    """,
    
    "shipping_policy.txt": """
    Shipping Information:
    - Standard shipping: 5-7 business days
    - Express shipping: 2-3 business days
    - Free shipping on orders over $50
    - International shipping available
    """,
    
    "q4_revenue.txt": """
    Q4 2025 Financial Report:
    - Total Revenue: $2.5 million
    - Growth: 15% year-over-year
    - Top product: Premium Widget ($800k)
    - Customer count: 12,500
    """
}


# ============================================================================
# SIMPLE SEARCH (Simulates Vector Database Search)
# ============================================================================

def search_knowledge_base(query: str) -> list[tuple[str, str]]:
    """
    Search knowledge base for relevant documents.
    In production, this would use vector embeddings and similarity search.
    """
    query_lower = query.lower()
    results = []
    
    for doc_name, content in KNOWLEDGE_BASE.items():
        # Simple keyword matching (real systems use semantic search)
        if any(keyword in content.lower() for keyword in query_lower.split()):
            results.append((doc_name, content.strip()))
    
    return results


# ============================================================================
# LLM WITHOUT RAG
# ============================================================================

class SimpleLLM:
    """LLM without access to knowledge base"""
    
    def generate(self, query: str) -> str:
        """Generate answer without context"""
        return "I don't have access to your company's specific policies or data."


# ============================================================================
# LLM WITH RAG
# ============================================================================

class RAGSystem:
    """LLM with RAG - has access to knowledge base"""
    
    def __init__(self):
        self.llm = SimpleLLM()
    
    def generate_with_rag(self, query: str) -> str:
        """Generate answer using RAG"""
        # Step 1: Retrieve relevant documents
        print("  🔍 Searching knowledge base...")
        relevant_docs = search_knowledge_base(query)
        
        if not relevant_docs:
            return "No relevant information found in knowledge base."
        
        print(f"  ✓ Found {len(relevant_docs)} relevant document(s)\n")
        
        # Step 2: Show what was retrieved
        for doc_name, _ in relevant_docs:
            print(f"  📄 Retrieved: {doc_name}")
        print()
        
        # Step 3: Create context from retrieved docs
        context = "\n\n".join([content for _, content in relevant_docs])
        
        # Step 4: Generate answer using context
        # In production, this would be sent to actual LLM (GPT-4, Claude, etc.)
        answer = self._generate_from_context(query, context)
        
        return answer
    
    def _generate_from_context(self, query: str, context: str) -> str:
        """Simulate LLM generating answer from context"""
        # In production, this would be:
        # response = openai.ChatCompletion.create(
        #     messages=[
        #         {"role": "system", "content": f"Context: {context}"},
        #         {"role": "user", "content": query}
        #     ]
        # )
        
        # For demo, we extract relevant info
        query_lower = query.lower()
        
        if "return" in query_lower:
            return "We offer a 30-day return policy. Items must be unused and in original packaging. Refunds are processed within 5-7 business days."
        elif "shipping" in query_lower:
            return "We offer standard shipping (5-7 days) and express shipping (2-3 days). Free shipping on orders over $50."
        elif "revenue" in query_lower or "q4" in query_lower:
            return "Q4 2025 revenue was $2.5 million, representing 15% year-over-year growth."
        else:
            return "Based on the retrieved documents, I found relevant information but need a more specific question."


# ============================================================================
# DEMO
# ============================================================================

def main():
    print("\n" + "="*70)
    print("Demo: RAG (Retrieval-Augmented Generation)")
    print("="*70 + "\n")
    
    # Initialize systems
    llm_without_rag = SimpleLLM()
    rag_system = RAGSystem()
    
    # Test queries
    queries = [
        "What is your return policy?",
        "What was the Q4 revenue?",
        "Tell me about shipping options"
    ]
    
    for i, query in enumerate(queries, 1):
        print(f"{i}️⃣  Query: '{query}'")
        print("-" * 70)
        
        # Without RAG
        print("❌ Without RAG:")
        answer = llm_without_rag.generate(query)
        print(f"  {answer}\n")
        
        # With RAG
        print("✅ With RAG:")
        answer = rag_system.generate_with_rag(query)
        print(f"  💬 Answer: {answer}\n")
        
        print()
    
    print("="*70)
    print("How RAG Works:")
    print("  1. User asks question")
    print("  2. Search knowledge base for relevant docs")
    print("  3. Retrieve top matching documents")
    print("  4. Send docs + question to LLM")
    print("  5. LLM generates answer using docs as context")
    print("\nWhy RAG is Powerful:")
    print("  • LLM can answer questions about YOUR data")
    print("  • No need to retrain the model")
    print("  • Always up-to-date (just update knowledge base)")
    print("  • More accurate (grounded in actual documents)")
    print("="*70 + "\n")


if __name__ == "__main__":
    main()
