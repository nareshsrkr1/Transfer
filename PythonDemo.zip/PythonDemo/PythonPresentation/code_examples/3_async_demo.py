"""
Example 3: Async Python (Concurrency)
======================================
Simple demonstration of async for I/O-bound tasks.
"""

import asyncio
import time

# ============================================================================
# SIMULATED I/O OPERATIONS
# ============================================================================

async def fetch_user(user_id: int) -> dict:
    """Simulates fetching user from API (I/O-bound)"""
    print(f"  ⏳ Fetching user {user_id}...")
    await asyncio.sleep(1)  # Simulates network delay
    print(f"  ✓ Got user {user_id}")
    return {"id": user_id, "name": f"User{user_id}"}


async def fetch_orders(user_id: int) -> list:
    """Simulates fetching orders from database (I/O-bound)"""
    print(f"  ⏳ Fetching orders for user {user_id}...")
    await asyncio.sleep(1)  # Simulates database query
    print(f"  ✓ Got orders for user {user_id}")
    return [{"id": 1, "amount": 99.99}, {"id": 2, "amount": 49.99}]


# ============================================================================
# SYNCHRONOUS VERSION (Slow)
# ============================================================================

def fetch_user_sync(user_id: int) -> dict:
    """Synchronous version - blocks while waiting"""
    print(f"  ⏳ Fetching user {user_id}...")
    time.sleep(1)  # Blocks the entire program
    print(f"  ✓ Got user {user_id}")
    return {"id": user_id, "name": f"User{user_id}"}


def get_user_data_sync(user_id: int):
    """Fetch user and orders synchronously"""
    user = fetch_user_sync(user_id)
    time.sleep(1)  # Simulating orders fetch
    orders = [{"id": 1, "amount": 99.99}]
    return {"user": user, "orders": orders}


# ============================================================================
# ASYNCHRONOUS VERSION (Fast)
# ============================================================================

async def get_user_data_async(user_id: int):
    """Fetch user and orders concurrently"""
    # Both run at the same time!
    user, orders = await asyncio.gather(
        fetch_user(user_id),
        fetch_orders(user_id)
    )
    return {"user": user, "orders": orders}


async def fetch_multiple_users(user_ids: list[int]):
    """Fetch multiple users concurrently"""
    # All users fetched at the same time!
    tasks = [fetch_user(user_id) for user_id in user_ids]
    users = await asyncio.gather(*tasks)
    return users


# ============================================================================
# DEMO
# ============================================================================

async def main():
    print("\n" + "="*60)
    print("Demo: Async Python (Concurrency)")
    print("="*60 + "\n")
    
    # Demo 1: Sequential vs Concurrent
    print("1️⃣  Synchronous (Sequential) - Slow")
    print("-" * 60)
    start = time.time()
    get_user_data_sync(1)
    print(f"⏱️  Time taken: {time.time() - start:.2f}s\n")
    
    print("2️⃣  Asynchronous (Concurrent) - Fast")
    print("-" * 60)
    start = time.time()
    await get_user_data_async(1)
    print(f"⏱️  Time taken: {time.time() - start:.2f}s\n")
    
    # Demo 2: Multiple concurrent requests
    print("3️⃣  Fetching 3 users concurrently")
    print("-" * 60)
    start = time.time()
    users = await fetch_multiple_users([1, 2, 3])
    print(f"⏱️  Time taken: {time.time() - start:.2f}s")
    print(f"📊 Fetched {len(users)} users\n")
    
    print("="*60)
    print("Key Takeaways:")
    print("  • Async is for I/O-bound tasks (API, DB, files)")
    print("  • Use 'async def' and 'await'")
    print("  • Use asyncio.gather() for concurrent operations")
    print("  • 3 API calls: Sequential=3s, Async=1s (3x faster!)")
    print("="*60 + "\n")


if __name__ == "__main__":
    asyncio.run(main())
