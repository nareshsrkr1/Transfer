"""
Example 4: Multiprocessing (Parallelism)
=========================================
Simple demonstration of multiprocessing for CPU-bound tasks.
"""

import time
from multiprocessing import Pool, cpu_count

# ============================================================================
# CPU-BOUND TASK
# ============================================================================

def process_numbers(numbers: list[int]) -> int:
    """CPU-intensive task: sum of squares"""
    result = sum(x * x for x in numbers)
    return result


def process_chunk(chunk: list[int]) -> int:
    """Process a chunk of numbers"""
    print(f"  🔄 Processing {len(chunk)} numbers...")
    result = process_numbers(chunk)
    print(f"  ✓ Chunk done: result={result}")
    return result


# ============================================================================
# SEQUENTIAL VERSION (Slow)
# ============================================================================

def process_sequential(data: list[int]) -> int:
    """Process all data sequentially"""
    return process_numbers(data)


# ============================================================================
# PARALLEL VERSION (Fast)
# ============================================================================

def process_parallel(data: list[int], num_processes: int = 4) -> int:
    """Process data using multiple processes"""
    # Split data into chunks
    chunk_size = len(data) // num_processes
    chunks = [
        data[i:i + chunk_size]
        for i in range(0, len(data), chunk_size)
    ]
    
    # Process chunks in parallel
    with Pool(processes=num_processes) as pool:
        results = pool.map(process_chunk, chunks)
    
    # Combine results
    return sum(results)


# ============================================================================
# DEMO
# ============================================================================

def main():
    print("\n" + "="*60)
    print("Demo: Multiprocessing (Parallelism)")
    print("="*60 + "\n")
    
    # Create test data
    data = list(range(1_000_000))  # 1 million numbers
    num_cores = cpu_count()
    
    print(f"📊 Processing {len(data):,} numbers")
    print(f"💻 Available CPU cores: {num_cores}\n")
    
    # Sequential processing
    print("1️⃣  Sequential Processing (1 core)")
    print("-" * 60)
    start = time.time()
    result_seq = process_sequential(data)
    time_seq = time.time() - start
    print(f"⏱️  Time: {time_seq:.2f}s")
    print(f"📈 Result: {result_seq:,}\n")
    
    # Parallel processing
    print(f"2️⃣  Parallel Processing ({num_cores} cores)")
    print("-" * 60)
    start = time.time()
    result_par = process_parallel(data, num_processes=num_cores)
    time_par = time.time() - start
    print(f"⏱️  Time: {time_par:.2f}s")
    print(f"📈 Result: {result_par:,}\n")
    
    # Comparison
    speedup = time_seq / time_par
    print("="*60)
    print(f"⚡ Speedup: {speedup:.2f}x faster with {num_cores} cores")
    print("="*60)
    print("\nKey Takeaways:")
    print("  • Multiprocessing is for CPU-bound tasks (math, processing)")
    print("  • Each process has its own Python interpreter")
    print("  • Bypasses the GIL (Global Interpreter Lock)")
    print(f"  • {num_cores} cores ≈ {num_cores}x speedup (for CPU work)")
    print("  • Use Pool.map() for simple parallelism")
    print("="*60 + "\n")


if __name__ == "__main__":
    main()
