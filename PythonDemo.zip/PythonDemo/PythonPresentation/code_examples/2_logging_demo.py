"""
Example 2: Logging vs Print
============================
Shows why logging is better than print() statements.
"""

import logging
import sys

# ============================================================================
# SETUP LOGGING
# ============================================================================

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger(__name__)


# ============================================================================
# BAD: Using print()
# ============================================================================

def process_order_bad(order_id, amount):
    """Bad practice: using print()"""
    print(f"Processing order {order_id}")  # No timestamp, no level
    
    if amount < 0:
        print(f"ERROR: Invalid amount {amount}")  # Can't filter these
        return False
    
    print(f"Order {order_id} processed successfully")
    return True


# ============================================================================
# GOOD: Using logging
# ============================================================================

def process_order_good(order_id, amount):
    """Good practice: using logging"""
    logger.info(f"Processing order {order_id}", extra={"order_id": order_id})
    
    if amount < 0:
        logger.error(f"Invalid amount {amount}", extra={"order_id": order_id, "amount": amount})
        return False
    
    logger.info(f"Order {order_id} processed successfully", extra={"order_id": order_id, "amount": amount})
    return True


# ============================================================================
# LOGGING LEVELS
# ============================================================================

def demonstrate_log_levels():
    """Shows different log levels"""
    logger.debug("Detailed debug information")  # Only in development
    logger.info("General information")  # Normal operations
    logger.warning("Something unexpected happened")  # Potential issues
    logger.error("Error occurred")  # Errors that need attention
    logger.critical("Critical error!")  # System might crash


# ============================================================================
# DEMO
# ============================================================================

def main():
    print("\n" + "="*60)
    print("Demo: Logging vs Print")
    print("="*60 + "\n")
    
    print("❌ BAD: Using print()")
    print("-" * 60)
    process_order_bad(123, 99.99)
    process_order_bad(456, -10)
    
    print("\n✅ GOOD: Using logging")
    print("-" * 60)
    process_order_good(123, 99.99)
    process_order_good(456, -10)
    
    print("\n📊 Different Log Levels:")
    print("-" * 60)
    demonstrate_log_levels()
    
    print("\n" + "="*60)
    print("Why Logging is Better:")
    print("  • Has timestamps (know when things happened)")
    print("  • Has levels (can filter in production)")
    print("  • Can add context (user_id, request_id)")
    print("  • Can send to monitoring systems (Datadog, CloudWatch)")
    print("  • Can be turned off in production (DEBUG logs)")
    print("="*60 + "\n")


if __name__ == "__main__":
    main()
