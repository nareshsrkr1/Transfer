"""
Example 6: LLM Basics - Tokenization
=====================================
Simple demonstration of how LLMs tokenize text.
"""

# ============================================================================
# SIMPLE TOKENIZER (Simplified version of what LLMs do)
# ============================================================================

class SimpleTokenizer:
    """Simplified tokenizer to demonstrate the concept"""
    
    def __init__(self):
        # Simulated vocabulary (real LLMs have 50k-100k tokens)
        self.vocab = {
            "I": 100,
            "love": 200,
            "pizza": 300,
            "Hello": 400,
            "world": 500,
            "Python": 600,
            "is": 700,
            "awesome": 800,
        }
    
    def tokenize(self, text: str) -> list[str]:
        """Split text into tokens (simplified)"""
        # Real tokenizers use subword tokenization (BPE, WordPiece)
        return text.split()
    
    def encode(self, text: str) -> list[int]:
        """Convert text to token IDs"""
        tokens = self.tokenize(text)
        token_ids = []
        
        for token in tokens:
            if token in self.vocab:
                token_ids.append(self.vocab[token])
            else:
                token_ids.append(999)  # Unknown token
        
        return token_ids
    
    def decode(self, token_ids: list[int]) -> str:
        """Convert token IDs back to text"""
        # Reverse lookup
        id_to_token = {v: k for k, v in self.vocab.items()}
        tokens = [id_to_token.get(id, "[UNK]") for id in token_ids]
        return " ".join(tokens)


# ============================================================================
# PREDICTION SIMULATION
# ============================================================================

class SimpleLLM:
    """Simplified LLM to demonstrate prediction"""
    
    def __init__(self):
        # Simulated knowledge (real LLMs have billions of parameters)
        self.knowledge = {
            "What is the capital of France": "Paris",
            "What is 2 + 2": "4",
            "Who wrote Python": "Guido van Rossum",
        }
    
    def predict_next_word(self, prompt: str, word_position: int) -> tuple[str, float]:
        """Predict next word with probability (simplified)"""
        # In reality, LLM calculates probability for ALL possible words
        predictions = {
            0: ("The", 0.95),
            1: ("capital", 0.88),
            2: ("of", 0.92),
            3: ("France", 0.94),
            4: ("is", 0.96),
            5: ("Paris", 0.99),
        }
        return predictions.get(word_position, ("", 0.0))
    
    def generate(self, prompt: str) -> str:
        """Generate response (simplified)"""
        # Check if we "know" the answer
        for question, answer in self.knowledge.items():
            if question in prompt:
                return answer
        return "I don't know"


# ============================================================================
# CONTEXT WINDOW DEMONSTRATION
# ============================================================================

class ContextWindow:
    """Demonstrates LLM's limited memory"""
    
    def __init__(self, max_tokens: int = 10):
        self.max_tokens = max_tokens
        self.history = []
    
    def add_message(self, message: str):
        """Add message to context"""
        tokens = message.split()
        self.history.extend(tokens)
        
        # Truncate if exceeds max
        if len(self.history) > self.max_tokens:
            removed = len(self.history) - self.max_tokens
            self.history = self.history[-self.max_tokens:]
            print(f"  ⚠️  Context full! Removed {removed} oldest tokens")
    
    def get_context(self) -> str:
        """Get current context"""
        return " ".join(self.history)


# ============================================================================
# DEMO
# ============================================================================

def main():
    print("\n" + "="*70)
    print("Demo: How LLMs Work - Tokenization & Prediction")
    print("="*70 + "\n")
    
    # Demo 1: Tokenization
    print("1️⃣  Tokenization (Text → Numbers)")
    print("-" * 70)
    tokenizer = SimpleTokenizer()
    
    text = "I love pizza"
    tokens = tokenizer.tokenize(text)
    token_ids = tokenizer.encode(text)
    
    print(f"Input text:  '{text}'")
    print(f"Tokens:      {tokens}")
    print(f"Token IDs:   {token_ids}")
    print(f"Decoded:     '{tokenizer.decode(token_ids)}'\n")
    
    # Demo 2: Prediction
    print("2️⃣  Prediction (Word by Word)")
    print("-" * 70)
    print("Question: 'What is the capital of France?'\n")
    print("LLM predicts word by word:")
    
    llm = SimpleLLM()
    words = ["The", "capital", "of", "France", "is", "Paris"]
    
    for i, word in enumerate(words):
        predicted_word, probability = llm.predict_next_word("", i)
        print(f"  Step {i+1}: '{predicted_word}' (probability: {probability*100:.0f}%)")
    
    print(f"\nFinal answer: '{' '.join(words)}'\n")
    
    # Demo 3: Context Window
    print("3️⃣  Context Window (Limited Memory)")
    print("-" * 70)
    context = ContextWindow(max_tokens=10)
    
    print(f"Context window size: {context.max_tokens} tokens\n")
    
    messages = [
        "Hello my name is Alice",
        "I love Python programming",
        "What is my name",  # This will be forgotten!
    ]
    
    for msg in messages:
        print(f"User: {msg}")
        context.add_message(msg)
        print(f"Context: '{context.get_context()}'\n")
    
    print("="*70)
    print("Key Takeaways:")
    print("  • Tokenization: Text → Numbers (LLMs work with numbers)")
    print("  • Prediction: LLM predicts next word using probabilities")
    print("  • Context Window: Limited memory (GPT-4: ~128k tokens)")
    print("  • Not a database: LLM predicts based on patterns, not facts")
    print("="*70 + "\n")


if __name__ == "__main__":
    main()
