"""
Example 1: Project Structure & Error Handling
==============================================
Simple demonstration of layered architecture and proper error handling.
"""

# ============================================================================
# CUSTOM EXCEPTIONS (Better than generic Exception)
# ============================================================================

class UserNotFoundError(Exception):
    """Raised when user doesn't exist"""
    def __init__(self, user_id):
        self.user_id = user_id
        super().__init__(f"User {user_id} not found")


class DatabaseError(Exception):
    """Raised when database operation fails"""
    pass


# ============================================================================
# REPOSITORY LAYER (Database operations)
# ============================================================================

class UserRepository:
    """Handles all database operations for users"""
    
    def __init__(self):
        # Simulated database
        self.users = {
            1: {"id": 1, "name": "Alice", "email": "alice@example.com"},
            2: {"id": 2, "name": "Bob", "email": "bob@example.com"}
        }
    
    def find_by_id(self, user_id: int) -> dict:
        """Find user by ID"""
        user = self.users.get(user_id)
        if not user:
            raise UserNotFoundError(user_id)
        return user
    
    def save(self, user: dict) -> dict:
        """Save user to database"""
        self.users[user['id']] = user
        return user


# ============================================================================
# SERVICE LAYER (Business logic)
# ============================================================================

class UserService:
    """Handles business logic for users"""
    
    def __init__(self, user_repo: UserRepository):
        self.user_repo = user_repo
    
    def get_user(self, user_id: int) -> dict:
        """Get user with business logic"""
        try:
            user = self.user_repo.find_by_id(user_id)
            # Business logic: Add full name
            user['full_name'] = f"{user['name']} <{user['email']}>"
            return user
        except UserNotFoundError as e:
            print(f"❌ Error: {e}")
            raise
    
    def create_user(self, user_id: int, name: str, email: str) -> dict:
        """Create new user with validation"""
        # Business logic: Validate email
        if '@' not in email:
            raise ValueError("Invalid email format")
        
        user = {"id": user_id, "name": name, "email": email}
        return self.user_repo.save(user)


# ============================================================================
# API LAYER (Would be FastAPI/Flask routes in real app)
# ============================================================================

class UserAPI:
    """Handles HTTP requests (simplified)"""
    
    def __init__(self, user_service: UserService):
        self.user_service = user_service
    
    def get_user_endpoint(self, user_id: int):
        """GET /users/{user_id}"""
        try:
            user = self.user_service.get_user(user_id)
            return {"status": "success", "data": user}
        except UserNotFoundError:
            return {"status": "error", "message": f"User {user_id} not found"}
        except Exception as e:
            return {"status": "error", "message": str(e)}


# ============================================================================
# DEMO
# ============================================================================

def main():
    print("\n" + "="*60)
    print("Demo: Layered Architecture & Error Handling")
    print("="*60 + "\n")
    
    # Setup layers (Dependency Injection)
    user_repo = UserRepository()
    user_service = UserService(user_repo)
    user_api = UserAPI(user_service)
    
    # Test 1: Get existing user
    print("1. Get existing user (ID=1):")
    result = user_api.get_user_endpoint(1)
    print(f"   {result}\n")
    
    # Test 2: Get non-existent user (proper error handling)
    print("2. Get non-existent user (ID=999):")
    result = user_api.get_user_endpoint(999)
    print(f"   {result}\n")
    
    # Test 3: Create new user
    print("3. Create new user:")
    try:
        new_user = user_service.create_user(3, "Charlie", "charlie@example.com")
        print(f"   ✓ Created: {new_user}\n")
    except Exception as e:
        print(f"   ✗ Failed: {e}\n")
    
    print("="*60)
    print("Key Takeaways:")
    print("  • API → Service → Repository (clear separation)")
    print("  • Custom exceptions (UserNotFoundError)")
    print("  • Dependency injection (easy to test)")
    print("="*60 + "\n")


if __name__ == "__main__":
    main()
