"""
Example 9: Agent Workflow - Simple Demo
========================================
Demonstrates the 4-phase agent workflow with a travel booking example.
Run this file to see how agents plan, execute, reflect, and respond.
"""

# Simulated APIs
def get_weather(city):
    return {"temp": 45, "condition": "rainy"}

def search_flights(dest, date):
    return [{"price": 380, "time": "8AM"}]

def search_hotels(city, max_price):
    return [{"name": "Hotel Rivoli", "price": 180}]

class TravelAgent:
    def process(self, request):
        print(f"Request: {request}\n")
        
        # Phase 1: Planning
        print("🧠 PLANNING: Break down task")
        print("  1. Search flights\n  2. Search hotels\n  3. Get weather\n")
        
        # Phase 2: Execution
        print("⚡ EXECUTION: Call tools")
        flights = search_flights("Paris", "Feb 2")
        hotels = search_hotels("Paris", 200)
        weather = get_weather("Paris")
        print(f"  ✓ Found {len(flights)} flights, {len(hotels)} hotels\n")
        
        # Phase 3: Reflection
        print("🔄 REFLECTION: Validate")
        print("  ✓ All data retrieved\n")
        
        # Phase 4: Response
        print("📊 RESPONSE:")
        print(f"  Flight: ${flights[0]['price']}")
        print(f"  Hotel: {hotels[0]['name']} ${hotels[0]['price']}")
        print(f"  Weather: {weather['temp']}°F\n")

if __name__ == "__main__":
    agent = TravelAgent()
    agent.process("Find flight to Paris on Feb 2, hotel under $200")
