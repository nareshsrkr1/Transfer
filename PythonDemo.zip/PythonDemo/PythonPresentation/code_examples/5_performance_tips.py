"""
Example 5: Performance Tips
============================
Simple demonstrations of common performance optimizations.
"""

import time
from functools import lru_cache

# ============================================================================
# TIP 1: Use Generators for Large Data (Memory Optimization)
# ============================================================================

def read_large_file_bad(filename: str) -> list:
    """❌ BAD: Loads entire file into memory"""
    with open(filename, 'r') as f:
        lines = f.readlines()  # Loads ALL lines at once
    return [line.strip().upper() for line in lines]


def read_large_file_good(filename: str):
    """✅ GOOD: Streams file line by line"""
    with open(filename, 'r') as f:
        for line in f:  # Processes one line at a time
            yield line.strip().upper()


# ============================================================================
# TIP 2: Cache Expensive Operations
# ============================================================================

def fibonacci_slow(n: int) -> int:
    """❌ BAD: Recalculates same values repeatedly"""
    if n < 2:
        return n
    return fibonacci_slow(n-1) + fibonacci_slow(n-2)


@lru_cache(maxsize=128)  # Caches last 128 results
def fibonacci_fast(n: int) -> int:
    """✅ GOOD: Caches results"""
    if n < 2:
        return n
    return fibonacci_fast(n-1) + fibonacci_fast(n-2)


# ============================================================================
# TIP 3: Reuse Connections/Sessions
# ============================================================================

class DatabaseConnectionBad:
    """❌ BAD: Creates new connection each time"""
    
    def query(self, sql: str):
        connection = self._create_connection()  # Expensive!
        result = connection.execute(sql)
        connection.close()
        return result
    
    def _create_connection(self):
        time.sleep(0.1)  # Simulates connection overhead
        return type('Connection', (), {'execute': lambda self, sql: f"Result for {sql}"})()


class DatabaseConnectionGood:
    """✅ GOOD: Reuses connection"""
    
    def __init__(self):
        self.connection = self._create_connection()  # Create once
    
    def query(self, sql: str):
        return self.connection.execute(sql)  # Reuse connection
    
    def _create_connection(self):
        time.sleep(0.1)  # Simulates connection overhead
        return type('Connection', (), {'execute': lambda self, sql: f"Result for {sql}"})()


# ============================================================================
# TIP 4: List Comprehension vs Loop
# ============================================================================

def process_with_loop(numbers: list[int]) -> list:
    """❌ SLOWER: Using loop"""
    result = []
    for n in numbers:
        result.append(n * n)
    return result


def process_with_comprehension(numbers: list[int]) -> list:
    """✅ FASTER: Using list comprehension"""
    return [n * n for n in numbers]


# ============================================================================
# DEMO
# ============================================================================

def main():
    print("\n" + "="*70)
    print("Demo: Performance Optimization Tips")
    print("="*70 + "\n")
    
    # Demo 1: Caching
    print("1️⃣  Caching Expensive Operations")
    print("-" * 70)
    
    n = 30
    start = time.time()
    result = fibonacci_slow(n)
    time_slow = time.time() - start
    print(f"❌ Without cache: fibonacci({n}) = {result} in {time_slow:.4f}s")
    
    start = time.time()
    result = fibonacci_fast(n)
    time_fast = time.time() - start
    print(f"✅ With cache:    fibonacci({n}) = {result} in {time_fast:.4f}s")
    print(f"⚡ Speedup: {time_slow/time_fast:.0f}x faster!\n")
    
    # Demo 2: Connection Reuse
    print("2️⃣  Reusing Connections")
    print("-" * 70)
    
    # Bad: New connection each time
    db_bad = DatabaseConnectionBad()
    start = time.time()
    for i in range(5):
        db_bad.query(f"SELECT * FROM users WHERE id={i}")
    time_bad = time.time() - start
    print(f"❌ New connection each time: {time_bad:.2f}s")
    
    # Good: Reuse connection
    db_good = DatabaseConnectionGood()
    start = time.time()
    for i in range(5):
        db_good.query(f"SELECT * FROM users WHERE id={i}")
    time_good = time.time() - start
    print(f"✅ Reuse connection:         {time_good:.2f}s")
    print(f"⚡ Speedup: {time_bad/time_good:.1f}x faster!\n")
    
    # Demo 3: List Comprehension
    print("3️⃣  List Comprehension vs Loop")
    print("-" * 70)
    
    numbers = list(range(100000))
    
    start = time.time()
    result1 = process_with_loop(numbers)
    time_loop = time.time() - start
    print(f"❌ Loop:               {time_loop:.4f}s")
    
    start = time.time()
    result2 = process_with_comprehension(numbers)
    time_comp = time.time() - start
    print(f"✅ List comprehension: {time_comp:.4f}s")
    print(f"⚡ Speedup: {time_loop/time_comp:.1f}x faster!\n")
    
    print("="*70)
    print("Key Takeaways:")
    print("  • Cache expensive operations (@lru_cache)")
    print("  • Reuse connections/sessions (don't recreate)")
    print("  • Use list comprehensions (faster than loops)")
    print("  • Stream large data with generators (saves memory)")
    print("  • Measure before optimizing (don't guess!)")
    print("="*70 + "\n")


if __name__ == "__main__":
    main()
