# Python Advanced & GenAI - Speaker Notes

## Slide 1: Production-Grade Python - Key Principles

### Speaker Notes (2 minutes):

**Opening (20 sec):**
"Let's start with what separates hobby code from production code. These 4 principles are non-negotiable in professional Python development."

**1. Clear Project Structure (30 sec):**
"Use layered architecture: API → Service → Repository
- **API layer**: Handles HTTP requests, validation
- **Service layer**: Business logic
- **Repository layer**: Database operations

This separation makes code testable and maintainable. You can swap databases without touching business logic."

**2. Strong Error Handling (30 sec):**
"Never let exceptions crash your app silently. Use meaningful exceptions:
- `UserNotFoundError` instead of generic `Exception`
- Catch specific exceptions, not bare `except:`
- Always log errors with context"

**3. Logging Over Print (20 sec):**
"Use `logging` module, not `print()`:
- Logs have timestamps and levels (DEBUG, INFO, ERROR)
- Can be sent to monitoring systems
- Include context: user_id, request_id, etc."

**4. Externalized Configuration (20 sec):**
"Never hardcode API keys or database URLs:
- Use environment variables
- Use Pydantic Settings for type safety
- Different configs for dev/staging/prod"

**See:** `code_examples/1_project_structure.py` and `code_examples/2_error_handling.py`

---

## Slide 2: Asynchronous Python (Concurrency)

### Speaker Notes (2-3 minutes):

**Opening (15 sec):**
"Async is for I/O-bound tasks - when you're waiting for something external."

**How It Works (45 sec):**
"Async uses a single thread with an event loop:
- While waiting for API response #1, start request #2
- No blocking - tasks cooperatively yield control
- Perfect for: web servers, API calls, database queries

**Key point:** This is concurrency, not parallelism. One CPU core handles many tasks by switching between them."

**When to Use (30 sec):**
"Use async when you're **waiting**:
- Making 100 API calls → Async makes it 100x faster
- Database queries
- File I/O
- Network requests

**Example:** Fetching 100 users sequentially takes 50 seconds. With async, it takes 1 second."

**Syntax (30 sec):**
```python
async def fetch_user(user_id):
    response = await http_client.get(f'/users/{user_id}')
    return response.json()

# Run concurrently
users = await asyncio.gather(
    fetch_user(1),
    fetch_user(2),
    fetch_user(3)
)
```

**See:** `code_examples/3_async_demo.py`

---

## Slide 3: Multiprocessing (Parallelism)

### Speaker Notes (2-3 minutes):

**Opening (15 sec):**
"Multiprocessing is for CPU-bound tasks - when you're computing."

**How It Works (45 sec):**
"Multiple processes, each with its own Python interpreter:
- Bypasses the GIL (Global Interpreter Lock)
- True parallel execution on multiple CPU cores
- Each process has separate memory

**Key point:** This is parallelism. 4 CPU cores = 4x speedup for CPU work."

**When to Use (30 sec):**
"Use multiprocessing when you're **computing**:
- Data processing (millions of rows)
- Image/video processing
- Machine learning training
- Mathematical calculations

**Example:** Processing 1 million numbers takes 4 seconds sequentially. With 4 processes, it takes 1 second."

**Syntax (30 sec):**
```python
from multiprocessing import Pool

def process_data(chunk):
    return sum(x * x for x in chunk)

with Pool(processes=4) as pool:
    results = pool.map(process_data, data_chunks)
```

**Quick Decision Rule (20 sec):**
- **Waiting** (API, DB, files) → Use **async**
- **Computing** (math, processing) → Use **multiprocessing**

**See:** `code_examples/4_multiprocessing_demo.py`

---

## Slide 4: Performance Optimizations

### Speaker Notes (2 minutes):

**Where Time Is Lost (30 sec):**
"Three main culprits:
1. **Blocking I/O** - Waiting for responses (fix with async)
2. **Repeated work** - Calling same API 100 times (fix with caching)
3. **Inefficient loading** - Loading 1GB file at once (fix with streaming)"

**Where Memory Is Lost (30 sec):**
"Common memory leaks:
1. **Loading full datasets** - Use generators/streaming
2. **Object retention** - Clear references when done
3. **Unbounded caches** - Set max size limits"

**High-Impact Optimizations (45 sec):**
"Focus on these:
1. **Stream data with generators:**
```python
# Bad: Loads 1GB into memory
data = [process(line) for line in file.readlines()]

# Good: Processes one line at a time
data = (process(line) for line in file)
```

2. **Reuse connections:**
```python
# Bad: Creates new connection each time
def get_user(id):
    conn = create_connection()
    return conn.query(id)

# Good: Reuse session
session = create_session()
def get_user(id):
    return session.query(id)
```

3. **Bound queues/caches:**
```python
from functools import lru_cache

@lru_cache(maxsize=1000)  # Only cache 1000 items
def expensive_function(x):
    return compute(x)
```"

**Rule of Thumb (15 sec):**
"Reduce work first, optimize code later. Caching one API call is better than optimizing a loop."

**See:** `code_examples/5_performance_tips.py`

---

## Slide 5: AI Application Layers

### Speaker Notes (2 minutes):

**Opening (15 sec):**
"Modern AI apps have 5 layers working together. Let's break them down."

**Layer 1: Data/Frontend (20 sec):**
"User input and validation:
- User types question in chat UI
- Validate input (not empty, safe content)
- Send to backend"

**Layer 2: Application Layer/Backend (25 sec):**
"The orchestrator:
- Receives user request
- Decides what to do (search docs? call API?)
- Manages user sessions
- Routes to AI layer"

**Layer 3: AI/LLM Layer (25 sec):**
"The brain:
- Processes natural language
- Understands intent
- Generates responses
- Examples: GPT-4, Claude, Gemini"

**Layer 4: Data Layer (25 sec):**
"Two types of storage:
- **Vector DB** (Pinecone, Weaviate): Stores embeddings for semantic search
- **Traditional DB** (PostgreSQL): Stores user data, chat history
- **Knowledge Base**: Company docs, manuals"

**Layer 5: External Integrations (20 sec):**
"Tools the AI can use:
- APIs (weather, flights, calendar)
- Databases
- Search engines"

**Example Flow (30 sec):**
"User: 'What's our Q4 revenue?'
1. Frontend → Backend
2. Backend searches vector DB for Q4 reports
3. Sends report + question to LLM
4. LLM generates answer
5. Backend → Frontend → User"

---

## Slide 6: How LLMs Work

### Speaker Notes (2-3 minutes):

**Training (30 sec):**
"LLMs learn from massive text:
- Reads billions of web pages, books, code
- Learns patterns: 'Paris' appears near 'France' and 'Eiffel Tower'
- Creates neural network with billions of parameters (GPT-4 has ~1.7 trillion)"

**Tokenization (30 sec):**
"Breaks text into tokens:
- 'I love pizza' → ['I', 'love', 'pizza']
- 'ChatGPT' → ['Chat', 'GPT']
- Converts to numbers: 'I'→314, 'love'→1891

Why? Computers work with numbers, not words."

**Prediction (60 sec):**
"LLM predicts next word using probability:

Question: 'What is the capital of France?'

LLM thinks:
1. 'The' (95% probability)
2. 'capital' (88%)
3. 'of' (92%)
4. 'France' (94%)
5. 'is' (96%)
6. 'Paris' (99%)

Output: 'The capital of France is Paris'

**Important:** It's not looking up facts - it's predicting based on patterns. This is why it sometimes makes mistakes ('hallucinates')."

**Context Window (30 sec):**
"LLM's short-term memory:
- GPT-3.5: ~4,000 words (8 pages)
- GPT-4: ~128,000 words (300 pages)
- Claude: ~200,000 words (a novel)

If conversation exceeds this, LLM forgets earlier parts."

**See:** `code_examples/6_llm_basics.py` (tokenization demo)

---

## Slide 7: RAG (Retrieval-Augmented Generation)

### Speaker Notes (2 minutes):

**The Problem (30 sec):**
"LLMs only know training data:
- GPT-4 trained until April 2023
- Doesn't know your company docs
- Doesn't know today's news
- Can't access private data"

**The Solution (60 sec):**
"RAG = Give LLM relevant docs before asking:

**Without RAG:**
User: 'What's our return policy?'
AI: 'I don't have access to your policies.'

**With RAG:**
1. Search knowledge base for 'return policy'
2. Find: 'Return_Policy.pdf'
3. Send to LLM: 'Context: 30-day returns... Question: What's our return policy?'
4. AI: 'We offer 30-day returns with original packaging...'

**Analogy:** Open-book exam vs closed-book exam."

**How It Works (30 sec):**
"5 steps:
1. User asks question
2. Convert question to embedding (vector)
3. Search vector DB for similar docs
4. Retrieve top 3-5 relevant docs
5. Send docs + question to LLM
6. LLM generates answer using docs"

**See:** `code_examples/7_rag_simple.py`

---

## Slide 8: Prompt Patterns

### Speaker Notes (2-3 minutes):

**Opening (15 sec):**
"How you ask determines answer quality. Four essential patterns:"

**1. Zero-Shot (30 sec):**
"Ask directly, no examples:
```
'Translate to French: Hello'
→ 'Bonjour'
```
Works for common tasks LLM has seen millions of times."

**2. Few-Shot (45 sec):**
"Give examples first:
```
'Translate to French:
English: Hello → French: Bonjour
English: Thank you → French: Merci
English: Goodbye → French: ?'
→ 'Au revoir'
```

**Power:** Teaches LLM your specific format/style. Great for custom tasks."

**3. Chain-of-Thought (45 sec):**
"Ask LLM to think step-by-step:
```
'Solve 25 × 4. Think step by step:
1. 25 × 2 = 50
2. 50 × 2 = 100'
```

**Why:** Shows reasoning, catches errors, builds trust."

**4. Role-Based (30 sec):**
"Set expertise level:
```
'You are a senior Python developer. Review this code...'
```

Changes tone and depth of response."

**See:** `code_examples/8_prompt_patterns.py`

---

## Slide 9: Agentic Workflow Pattern

### Speaker Notes (2 minutes):

**Opening (15 sec):**
"Agents execute tasks autonomously through 4 phases."

**Phase 1: Planning (30 sec):**
"LLM breaks task into steps:

User: 'Find flight to Paris on Feb 2'

LLM plans:
1. Check calendar for Feb 2
2. Search flights to Paris
3. Get weather forecast
4. Present options"

**Phase 2: Execution (30 sec):**
"Calls tools/APIs:
- Calls calendar API → Feb 2 is Friday
- Calls flight API → 3 flights found
- Calls weather API → 45°F, rainy"

**Phase 3: Reflection (30 sec):**
"Validates results:
- ✓ Flight found?
- ✓ Date correct?
- ✓ All info gathered?

If not, re-plans and tries again."

**Phase 4: Response (15 sec):**
"Synthesizes results:
'I found 3 flights to Paris on Friday Feb 2. Weather will be rainy (45°F). Cheapest is $380 at 8 AM.'"

**See:** `code_examples/9_agent_workflow.py`

---

## Slide 10: Integration Patterns

### Speaker Notes (2 minutes):

**Pattern 1: Function Calling (40 sec):**
"OpenAI/Anthropic native:
1. Define functions as JSON schemas
2. LLM decides when to call them
3. Your code executes function
4. Return result to LLM

**Example:** LLM sees user asks about weather, calls `get_weather('Paris')`, you execute it, return result."

**Pattern 2: Tool Use (LangChain) (40 sec):**
"Higher-level framework:
- Wrap functions as 'tools'
- Agent chains tool calls automatically
- Built-in retry logic

**Easier but less control than raw function calling.**"

**Pattern 3: ReAct (40 sec):**
"Reasoning + Acting pattern:
```
Thought: I need user's order
Action: search_database(order_id=123)
Observation: {status: 'shipped'}
Thought: Now check shipping
Action: check_shipping(tracking=ABC)
Observation: {eta: 'Feb 5'}
Thought: I have all info
Answer: Your order ships Feb 5
```

**Transparent reasoning - great for debugging.**"

**See:** `code_examples/10_function_calling.py`

---

## Quick Reference Card

**Async vs Multiprocessing:**
- Waiting (API, DB) → **async**
- Computing (math, ML) → **multiprocessing**

**LLM Basics:**
- Training → Tokenization → Prediction → Context Window

**RAG:**
- Search docs → Give to LLM → Generate answer

**Prompt Patterns:**
- Zero-shot: Direct question
- Few-shot: Give examples
- Chain-of-thought: Think step-by-step
- Role-based: Set expertise

**Agent Workflow:**
- Plan → Execute → Reflect → Respond
