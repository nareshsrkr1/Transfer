# Python Advanced & GenAI Presentation

## 📁 Folder Structure

```
PythonPresentation/
├── SPEAKER_NOTES.md          # Complete speaker notes for all slides
├── README.md                  # This file
└── code_examples/             # Executable Python examples
    ├── 1_project_structure.py
    ├── 2_logging_demo.py
    ├── 3_async_demo.py
    ├── 4_multiprocessing_demo.py
    ├── 5_performance_tips.py
    ├── 6_llm_basics.py
    ├── 7_rag_simple.py
    ├── 8_prompt_patterns.py
    └── 9_agent_workflow.py
```

## 🎯 How to Use

### 1. Read Speaker Notes
Open `SPEAKER_NOTES.md` for detailed talking points for each slide with timing.

### 2. Run Code Examples
Each file is standalone and can be run directly:

```bash
# Navigate to code_examples folder
cd code_examples

# Run any example
python 1_project_structure.py
python 3_async_demo.py
python 7_rag_simple.py
```

### 3. During Presentation
- Keep `SPEAKER_NOTES.md` open for reference
- Run code examples live to demonstrate concepts
- All examples are simple and easy to understand

## 📚 Code Examples Overview

| File | Concept | Runtime |
|------|---------|---------|
| `1_project_structure.py` | Layered architecture & error handling | <1s |
| `2_logging_demo.py` | Logging vs print statements | <1s |
| `3_async_demo.py` | Async concurrency for I/O | ~3s |
| `4_multiprocessing_demo.py` | Parallel processing for CPU | ~5s |
| `5_performance_tips.py` | Caching, connection reuse | ~2s |
| `6_llm_basics.py` | Tokenization & prediction | <1s |
| `7_rag_simple.py` | RAG with knowledge base | <1s |
| `8_prompt_patterns.py` | 4 prompting techniques | <1s |
| `9_agent_workflow.py` | 4-phase agent workflow | <1s |

## 💡 Tips for Presentation

1. **Start with basics** (project structure, logging)
2. **Show async vs multiprocessing** side-by-side
3. **Demonstrate RAG** - very visual and impactful
4. **Run agent workflow** - shows everything together

## 🔧 Requirements

All examples use Python standard library except:
- `3_async_demo.py` - requires Python 3.7+
- `4_multiprocessing_demo.py` - works best with 4+ CPU cores

No external packages needed! All examples are self-contained.

## 📖 Slide Mapping

- **Slide 1**: Production Principles → `1_project_structure.py`, `2_logging_demo.py`
- **Slide 2**: Async Python → `3_async_demo.py`
- **Slide 3**: Multiprocessing → `4_multiprocessing_demo.py`
- **Slide 4**: Performance → `5_performance_tips.py`
- **Slide 5-6**: LLM Basics → `6_llm_basics.py`
- **Slide 7**: RAG → `7_rag_simple.py`
- **Slide 8**: Prompts → `8_prompt_patterns.py`
- **Slide 9-10**: Agents → `9_agent_workflow.py`

## ✅ Quick Test

Run this to test all examples:

```bash
cd code_examples
for file in *.py; do echo "Running $file..."; python "$file"; done
```

Good luck with your presentation! 🚀
