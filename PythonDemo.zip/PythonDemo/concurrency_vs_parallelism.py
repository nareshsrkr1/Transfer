import asyncio
import time
import os
from multiprocessing import Process

# ---------------- CONCURRENCY (ASYNC) ----------------

async def async_task(name):
    print(f"[{time.time():.2f}] ASYNC  Task {name} START | PID={os.getpid()}")
    await asyncio.sleep(1)
    print(f"[{time.time():.2f}] ASYNC  Task {name} END   | PID={os.getpid()}")

async def run_async():
    print("\n=== CONCURRENCY (ASYNC) ===")
    start = time.time()
    await asyncio.gather(
        async_task("A"),
        async_task("B"),
        async_task("C")
    )
    print(f"ASYNC Total time: {time.time() - start:.2f}s")


# ---------------- PARALLELISM (MULTIPROCESSING) ----------------

def process_task(name):
    print(f"[{time.time():.2f}] PROC   Task {name} START | PID={os.getpid()}")
    start = time.time()
    while time.time() - start < 1:
        pass  # CPU-bound work
    print(f"[{time.time():.2f}] PROC   Task {name} END   | PID={os.getpid()}")

def run_processes():
    print("\n=== PARALLELISM (MULTIPROCESSING) ===")
    start = time.time()

    processes = [
        Process(target=process_task, args=("A",)),
        Process(target=process_task, args=("B",)),
        Process(target=process_task, args=("C",))
    ]

    for p in processes:
        p.start()

    for p in processes:
        p.join()

    print(f"PROC Total time: {time.time() - start:.2f}s")



if __name__ == "__main__":
    asyncio.run(run_async())
    run_processes()
